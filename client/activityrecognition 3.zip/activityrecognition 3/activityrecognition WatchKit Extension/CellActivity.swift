//
//  CellActivity.swift
//  activityrecognition
//
//  Created by Pongpanot Chuaysakun on 2/5/2559 BE.
//  Copyright © 2559 Pongpanot Chuaysakun. All rights reserved.
//

import WatchKit

class CellActivity: NSObject {
    

    @IBOutlet var cellAct: WKInterfaceLabel!
    func showItem(title: String) {
        self.cellAct.setText(title)
    }
}
