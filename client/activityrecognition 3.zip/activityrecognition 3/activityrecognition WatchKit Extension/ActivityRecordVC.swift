//
//  ActivityRecordVC.swift
//  activityrecognition
//
//  Created by Pongpanot Chuaysakun on 2/5/2559 BE.
//  Copyright © 2559 Pongpanot Chuaysakun. All rights reserved.
//

import WatchKit
import Foundation


class ActivityRecordVC: WKInterfaceController {
    @IBOutlet var buttonState: WKInterfaceButton!
    @IBOutlet var activityType: WKInterfaceLabel!
    @IBOutlet var date: WKInterfaceDate!
    @IBOutlet var recordTime: WKInterfaceTimer!
    private var state:Bool!
    let coreMotion = CoreMotionClass()
    //let healthStore = HealthKitClass()
    //let data = DataControl()
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        activityType.setText(context as? String)
        date.setTimeZone(NSTimeZone.defaultTimeZone())
        state = false
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func DidChangeState() {
        if(!state){
            recordTime.setDate(NSDate(timeIntervalSinceNow: 0))
            recordTime.start()
            state = true
            buttonState.setTitle("Stop")
            //healthStore.start()
            coreMotion.Active()
        }else{
            recordTime.stop()
            state = false
            buttonState.setTitle("Start")
            //healthStore.stop()
            coreMotion.Disable()
        }
    }
    @IBAction func ResetTime() {
        state = false
        recordTime.stop()
        recordTime.setDate(NSDate(timeIntervalSinceNow: 0))
        buttonState.setTitle("Start")
        coreMotion.Disable()
    }
}
