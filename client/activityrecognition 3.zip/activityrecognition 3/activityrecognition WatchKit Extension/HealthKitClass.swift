//
//  HealthKitClass.swift
//  activityrecognition
//
//  Created by Pongpanot Chuaysakun on 2/18/2559 BE.
//  Copyright © 2559 Pongpanot Chuaysakun. All rights reserved.
//
/*
import WatchKit
import HealthKit
import WatchConnectivity
class HealthKitClass: NSObject, HKWorkoutSessionDelegate {
    let healthStore = HKHealthStore()
        //State of the app - is the workout activated
    var workoutActive = false
    
    // define the activity type and location
    var workoutSession : HKWorkoutSession?
    
    let stepUnit = HKUnit(fromString: "count")
    let heartRateUnit = HKUnit(fromString: "count/min")
    let bodytempUnit = HKUnit(fromString: "degC")
    
    
    var heartrateAnchor = HKQueryAnchor(fromValue: Int(HKAnchoredObjectQueryNoAnchor))
    
    override init() {
        guard HKHealthStore.isHealthDataAvailable() == true else {
            print("not available")
            return
        }
        
        let setHK = Set(arrayLiteral:   HKQuantityType.quantityTypeForIdentifier(HKQuantityTypeIdentifierStepCount)!,
                                        HKQuantityType.quantityTypeForIdentifier(HKQuantityTypeIdentifierHeartRate)!,
                                        HKQuantityType.quantityTypeForIdentifier(HKQuantityTypeIdentifierBodyTemperature)!)
        
        healthStore.requestAuthorizationToShareTypes(nil, readTypes: setHK) { (success, error) -> Void in
            if success == false {
                print("not available")
            }
        }
    }
    func stop() {
            //finish the current workout
            self.workoutActive = false
            if let workout = self.workoutSession {
                healthStore.endWorkoutSession(workout)
            }
        } 
    
    func start(){
            //start a new workout
            self.workoutActive = true
            startWorkout()
        }
    
    func workoutDidStart(date : NSDate) {
        if let query = createHeartRateStreamingQuery(date) {
            healthStore.executeQuery(query)
        }
        if let query = createBodyTempStreamingQuery(){
            healthStore.executeQuery(query)
        }
        if let query = createStepStreamingQuery(){
            healthStore.executeQuery(query)
        }
    }
    func workoutDidEnd(date : NSDate) {
        if let query = createHeartRateStreamingQuery(date) {
            healthStore.stopQuery(query)
        }
        if let query = createBodyTempStreamingQuery(){
            healthStore.stopQuery(query)
        }
        if let query = createStepStreamingQuery(){
            healthStore.stopQuery(query)
        }

    }
    
    func startWorkout() {
        self.workoutSession = HKWorkoutSession(activityType: HKWorkoutActivityType.CrossTraining, locationType: HKWorkoutSessionLocationType.Indoor)
        self.workoutSession?.delegate = self
        healthStore.startWorkoutSession(self.workoutSession!)
    }
    
    func workoutSession(workoutSession: HKWorkoutSession, didChangeToState toState: HKWorkoutSessionState, fromState: HKWorkoutSessionState, date: NSDate) {
        switch toState {
        case .Running:
            workoutDidStart(date)
        case .Ended:
            workoutDidEnd(date)
        default:
            print("Unexpected state \(toState)")
        }
    }
    func workoutSession(workoutSession: HKWorkoutSession, didFailWithError error: NSError) {
        // Do nothing for now
        NSLog("Workout error: \(error.userInfo)")
    }
    

    
    func createHeartRateStreamingQuery(workoutStartDate: NSDate) -> HKQuery? {
        // adding predicate will not work
        // let predicate = HKQuery.predicateForSamplesWithStartDate(workoutStartDate, endDate: nil, options: HKQueryOptions.None)
        
        guard let quantityType = HKObjectType.quantityTypeForIdentifier(HKQuantityTypeIdentifierHeartRate) else { return nil }
        
        let heartRateQuery = HKAnchoredObjectQuery(type: quantityType, predicate: nil, anchor: heartrateAnchor, limit: Int(HKObjectQueryNoLimit)) { (query, sampleObjects, deletedObjects, newAnchor, error) -> Void in
            guard let newAnchor = newAnchor else {return}
            self.heartrateAnchor = newAnchor
            self.updateHeartRate(sampleObjects)
        }
        
        heartRateQuery.updateHandler = {(query, samples, deleteObjects, newAnchor, error) -> Void in
            guard let newAnchor = newAnchor else {return}
            self.heartrateAnchor = newAnchor
            self.updateHeartRate(samples)
        }
        return heartRateQuery
    }
    func updateHeartRate(samples: [HKSample]?) {
        guard let heartRateSamples = samples as? [HKQuantitySample] else {return}
            guard let sample = heartRateSamples.first else{return}
            let value = sample.quantity.doubleValueForUnit(self.heartRateUnit)
           print("Heartrate \(value)")
            let timestamp = NSDate().formattedISO8601
            let parameter = [
                "Type":NSUserDefaults.standardUserDefaults().valueForKey("type") as! String,
                "Count":"\(value)",
                "Time":"\(timestamp)"
            ]
            let data = ["datatype":"heartrate",
                "data":parameter]
            WCSession.defaultSession().transferUserInfo(data as! [String : AnyObject])
    }
    
    
    
    func createBodyTempStreamingQuery() -> HKQuery? {
    
        guard let quantityType = HKObjectType.quantityTypeForIdentifier(HKQuantityTypeIdentifierBodyTemperature) else { return nil }
        let BodyTemperatureQuery = HKAnchoredObjectQuery(type: quantityType, predicate: nil, anchor: nil, limit: Int(HKObjectQueryNoLimit)) { (query, sampleObjects, deletedObjects, newAnchor, error) -> Void in
            self.updateTemp(sampleObjects)
        }
        
        BodyTemperatureQuery.updateHandler = {(query, samples, deleteObjects, newAnchor, error) -> Void in
            self.updateTemp(samples)
        }
        return BodyTemperatureQuery
    }
    func updateTemp(samples: [HKSample]?) {
        guard let tempSamples = samples as? [HKQuantitySample] else {return}
            guard let sample = tempSamples.first else{return}
            let value = sample.quantity.doubleValueForUnit(self.bodytempUnit)
            print("bodytemp \(value)")
    }
    
    
    func createStepStreamingQuery() -> HKQuery? {
        guard let quantityType = HKObjectType.quantityTypeForIdentifier(HKQuantityTypeIdentifierStepCount) else { return nil }
        let StepCountQuery = HKAnchoredObjectQuery(type: quantityType, predicate: nil, anchor: nil, limit: Int(HKObjectQueryNoLimit)) { (query, sampleObjects, deletedObjects, newAnchor, error) -> Void in
            self.updateStep(sampleObjects)
        }
        
        StepCountQuery.updateHandler = {(query, samples, deleteObjects, newAnchor, error) -> Void in
            self.updateStep(samples)
        }
        return StepCountQuery
    }
    func updateStep(samples: [HKSample]?) {
        guard let stepSamples = samples as? [HKQuantitySample] else {return}
                    guard let sample = stepSamples.first else{return}
            let value = sample.quantity.doubleValueForUnit(self.stepUnit)
            print("step \(value)")
    }
}
 */
