//
//  CoreMotionClass.swift
//  activityrecognition
//
//  Created by Pongpanot Chuaysakun on 1/20/2559 BE.
//  Copyright © 2559 Pongpanot Chuaysakun. All rights reserved.
//

import Foundation
import CoreMotion
import WatchConnectivity
class CoreMotionClass {
    //let data = DataControl()
    let motionManager = CMMotionManager()
    func CreateAccelerometer(){
        motionManager.accelerometerUpdateInterval = 1.0/50.0
        if (motionManager.accelerometerAvailable == true) {
            let handler:CMAccelerometerHandler = {(data: CMAccelerometerData?, error: NSError?) -> Void in
                //self.data.addAccel(x: "\(data!.acceleration.x)", y: "\(data!.acceleration.y)", z: "\(data!.acceleration.z)")
                    let timestamp = NSDate().formattedISO8601
                    let parameter = [
                        "Type":NSUserDefaults.standardUserDefaults().valueForKey("type") as! String,
                        "X":"\(data!.acceleration.x)",
                        "Y":"\(data!.acceleration.y)",
                        "Z":"\(data!.acceleration.z)",
                        "Time":"\(timestamp)"
                    ]
                    let data = ["datatype":"accel",
                                "data":parameter]
                    if (WCSession.defaultSession().reachable) {
                    //print("pass1")
                        WCSession.defaultSession().sendMessage(data as! [String : AnyObject],
                                                           replyHandler: { (_: [String : AnyObject]) -> Void in
                                                            print("hello")
                        },errorHandler: { (NSError) -> Void in
                            print("hello2")
                    })
                    }else{
                        print("pass2")
                        WCSession.defaultSession().transferUserInfo(data as! [String : AnyObject])
                    }
            }
            motionManager.startAccelerometerUpdatesToQueue(NSOperationQueue.currentQueue()!, withHandler: handler)
        }else{
            print("Accelerometer x = error")
            print("Accelerometer y = error")
            print("Accelerometer z = error")
            
            //demo
            /*for _ in 1...1{
                let timestamp = NSDate().formattedISO8601
                let parameter = [
                    "Type":NSUserDefaults.standardUserDefaults().valueForKey("type") as! String,
                    "X":"5",
                    "Y":"3",
                    "Z":"1",
                    "Time":"\(timestamp)"
                ]
                let data = ["datatype":"accel","data":parameter]
                if (WCSession.defaultSession().reachable) {
                    print("pass1")
                    WCSession.defaultSession().sendMessage(data as! [String : AnyObject],
                    replyHandler: { (_: [String : AnyObject]) -> Void in
                        print("hello")
                    },errorHandler: { (NSError) -> Void in
                        print("hello2")
                    })
                }else{
                    print("pass2")
                    WCSession.defaultSession().transferUserInfo(data as! [String : AnyObject])
                }
            }*/
            //
        }
    }
    func StopAccelerometer(){
        motionManager.stopAccelerometerUpdates()
    }

    
    func Active(){
        CreateAccelerometer()
    }
    func Disable(){
        StopAccelerometer()
    }
}
