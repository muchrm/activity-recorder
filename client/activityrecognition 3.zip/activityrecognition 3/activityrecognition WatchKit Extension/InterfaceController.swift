//
//  InterfaceController.swift
//  activityrecognition WatchKit Extension
//
//  Created by Pongpanot Chuaysakun on 1/19/2559 BE.
//  Copyright © 2559 Pongpanot Chuaysakun. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    var items: [String]!
    
    @IBOutlet var actTable: WKInterfaceTable!
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        items = ["Walk","Jog","Stand","Stairs","Sit"]
        // Configure interface objects here.
        loadTableData()
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
    }
    private func loadTableData() {
        actTable.setNumberOfRows(items.count, withRowType: "CellActivity")
        var i=0
        for anItem in items {
            let row = actTable.rowControllerAtIndex(i) as! CellActivity
            row.showItem(anItem)
            i += 1
        }
        
    }
    override func table(table: WKInterfaceTable, didSelectRowAtIndex rowIndex: Int) {
        let item = items[rowIndex]
        NSUserDefaults.standardUserDefaults().setValue(item, forKeyPath: "type")
        self.pushControllerWithName("ActivityRecord", context: item)
    }
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }


}
