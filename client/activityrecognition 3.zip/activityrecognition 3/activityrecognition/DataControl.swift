//
//  DataControl.swift
//  activityrecognition
//
//  Created by Pongpanot Chuaysakun on 2/1/2559 BE.
//  Copyright © 2559 Pongpanot Chuaysakun. All rights reserved.
//

import Foundation
import RealmSwift
class DataControl{
    let queue = NSOperationQueue()
    var str = [NSDictionary]()
    init() {
        queue.maxConcurrentOperationCount = -1
    }
    let name = "user2"
    let device = "apple watch"
    func addAccel(x x:String,y:String,z:String,time:String,type:String){
        let result = Result()
        result.Name = self.name
        result.Type = type
        result.Device = self.device
        result.Field = "{\"X\":\"\(x)\",\"Y\":\"\(y)\",\"Z\":\"\(z)\"}"
        result.Time = time
        result.DataName = "accel"
        let realm = try! Realm()
        try! realm.write {
            realm.add(result)
        }
    }
    func addHeartrate(count count:String,time:String,type:String){
        let result = Result()
        result.Name = self.name
        result.Type = type
        result.Device = self.device
        result.Field = "{\"Count\":\"\(count)\"}"
        result.Time = time
        result.DataName = "heartrate"
        let realm = try! Realm()
        try! realm.write {
            realm.add(result)
        }
    }
    func post(){
        let url = "http://10.16.64.97/addarray"
        let realm = try! Realm()
        let theDog = realm.objects(Result)
        if theDog.count > 0 {
            for obj in theDog{
                str.append(obj.toDictionary())
            }
            try! realm.write {
                realm.delete(theDog)
            }
        }else{
            print("nodata in realm")
        }
        if str.count > 0{
            print(str)
            do {
                let jsonData = try NSJSONSerialization.dataWithJSONObject(str, options: NSJSONWritingOptions.PrettyPrinted)
                let jsonString = NSString(data:jsonData, encoding: NSUTF8StringEncoding)! as String
                print(jsonString)
            } catch let error as NSError {
                print(error)
            }
            let request = NSMutableURLRequest(URL: NSURL(string: "\(url)")!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "POST"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            request.HTTPBody = try! NSJSONSerialization.dataWithJSONObject(str, options: [])
            let task = session.dataTaskWithRequest(request) { data, response, error in
                guard data != nil else {
                    print("no data found: \(error)")
                return
                }
                self.str = []
            }
            task.resume()
        }else{
            print("nodata in str")
        }
    }
    
}



class Result:Object{
    dynamic var Name = ""
    dynamic var Type = ""
    dynamic var Device = ""
    dynamic var Time = ""
    dynamic var Field = ""
    dynamic var DataName = ""
}

