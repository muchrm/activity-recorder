//
//  ViewController.swift
//  activityrecognition
//
//  Created by Pongpanot Chuaysakun on 1/19/2559 BE.
//  Copyright © 2559 Pongpanot Chuaysakun. All rights reserved.
//

import UIKit
import RealmSwift
class ViewController: UIViewController{
    let data = DataControl()
    override func viewDidLoad() {
        super.viewDidLoad()
        NSTimer.scheduledTimerWithTimeInterval(5, target: self, selector: #selector(self.post), userInfo: nil, repeats: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func post(){
        self.data.post()
    }

}

